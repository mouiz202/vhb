return {
    -- Useable item, can be `false` to disable it
    item = 'laptop',

    slots = 10,
    weight = 1000
}
