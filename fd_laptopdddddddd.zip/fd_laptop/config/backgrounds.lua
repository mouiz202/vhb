---@return BackgroundSource[]
return {
    {
        src = '1.jpg'
    },
    {
        src = '2.png'
    },
    {
        src = '3.jpg'
    },
    {
        src = '4.jpg'
    },
    {
        src = '5.jpg'
    },
    {
        src = '6.jpg'
    },
    {
        src = '7.jpg'
    },
    {
        src = '8.jpg'
    },
    {
        src = '9.jpg'
    },
    {
        src = '10.jpg'
    },
    {
        src = '11.jpg'
    }
}
